import { z } from 'zod';

export const CrowdDataSchema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  density: z.number().min(0).max(1), // 0 to 1 scale
  timestamp: z.number(),
  gateId: z.string().optional(),
});

export const UserProfileSchema = z.object({
  uid: z.string(),
  displayName: z.string().nullable(),
  email: z.string().email(),
  photoURL: z.string().url().nullable(),
  role: z.enum(['attendee', 'staff', 'admin']).default('attendee'),
  highContrast: z.boolean().default(false),
  darkMode: z.boolean().default(false),
});

export const QueuePredictionSchema = z.object({
  gateId: z.string(),
  waitTimeMinutes: z.number().nonnegative(),
  trend: z.enum(['rising', 'stable', 'falling']),
  lastUpdated: z.number(),
});

export type CrowdData = z.infer<typeof CrowdDataSchema>;
export type UserProfile = z.infer<typeof UserProfileSchema>;
export type QueuePrediction = z.infer<typeof QueuePredictionSchema>;
