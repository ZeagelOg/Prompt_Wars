import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Global error handling for environment-specific quirks
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    // Broadly suppress any variation of AbortError as they are non-fatal 
    // lifecycle artifacts in this environment
    const reason = event.reason;
    const isAbortError = 
      reason === 'AbortError' ||
      reason?.name === 'AbortError' || 
      reason?.code === 20 || // DOMException.ABORT_ERR
      reason?.message?.toLowerCase().includes('abort') ||
      reason?.message?.toLowerCase().includes('transaction was aborted');

    const isMessagingError = 
      reason?.message?.includes('messaging/unsupported-browser') ||
      reason?.code === 'messaging/unsupported-browser';

    if (isAbortError || isMessagingError) {
      event.preventDefault();
      console.warn('Suppressed non-fatal error:', reason?.message || reason);
    }
  });

  // Handle errors mentioned in your logs (IndexedDB connection closing)
  window.addEventListener('error', (event) => {
    if (event.message?.toLowerCase().includes('idbdatabase') || 
        event.message?.toLowerCase().includes('abort')) {
      event.preventDefault();
      console.warn('Recovered from background environment error.');
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
