import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { auth, googleProvider, db, handleFirestoreError } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { UserProfileSchema, type UserProfile } from '../types/schemas';

let loginPromise: Promise<UserProfile | null> | null = null;

export const fetchUserProfile = async (uid: string): Promise<UserProfile | null> => {
  const userRef = doc(db, 'users', uid);
  try {
    const userSnap = await getDoc(userRef);
    if (userSnap.exists()) {
      return userSnap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    return handleFirestoreError(error, 'get', `users/${uid}`);
  }
};

export const signInWithGoogle = async (): Promise<UserProfile | null> => {
  if (loginPromise) return loginPromise;

  // We initiate the popup logic immediately
  loginPromise = (async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      
      const existingProfile = await fetchUserProfile(user.uid);
      
      if (!existingProfile) {
        const newProfile: UserProfile = {
          uid: user.uid,
          displayName: user.displayName || 'Anonymous',
          email: user.email!,
          photoURL: user.photoURL || null,
          role: user.email === 'bhowmiklisha7@gmail.com' ? 'admin' : 'attendee',
          highContrast: false,
          darkMode: false,
        };
        
        UserProfileSchema.parse(newProfile);
        await setDoc(doc(db, 'users', user.uid), newProfile);
        return newProfile;
      }

      // Special check to auto-promote our admin email even if profile exists
      if (user.email === 'bhowmiklisha7@gmail.com' && existingProfile.role !== 'admin') {
        const updatedProfile = { ...existingProfile, role: 'admin' as const };
        await setDoc(doc(db, 'users', user.uid), updatedProfile);
        return updatedProfile;
      }

      return existingProfile;
    } catch (error: any) {
      if (error.code === 'auth/popup-blocked') {
        alert("The login popup was blocked by your browser. Please enable popups for this site and try again.");
      } else if (error.code !== 'auth/cancelled-popup-request' && error.code !== 'auth/popup-closed-by-user') {
        console.error("Sign-in error:", error.code, error.message);
      }
      return null;
    } finally {
      loginPromise = null;
    }
  })();

  return loginPromise;
};

export const logout = () => signOut(auth);

export const subscribeToAuthChanges = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, (user) => {
    // If user exists, we might want to verify they are still in firestore
    callback(user);
  });
};
