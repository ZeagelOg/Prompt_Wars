import { getToken, onMessage } from 'firebase/messaging';
import { messaging, db, auth } from './firebase';
import { doc, setDoc } from 'firebase/firestore';

export const requestNotificationPermission = async () => {
  const m = await messaging;
  if (!m) return;

  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      // Note: In a production app, you'd provide your VAPID key here
      // const token = await getToken(m, { vapidKey: 'YOUR_VAPID_KEY' });
      const token = await getToken(m).catch(e => {
        console.warn("FCM Token fetch failed (likely missing VAPID):", e.message);
        return null;
      });

      if (token && auth.currentUser) {
        await setDoc(doc(db, 'users', auth.currentUser.uid), {
          fcmToken: token,
          notificationsEnabled: true,
          updatedAt: Date.now()
        }, { merge: true });
        return token;
      }
    }
  } catch (error) {
    console.error('Error requesting notification permission:', error);
  }
};

export const onMessageReceived = async (callback: (payload: any) => void) => {
  const m = await messaging;
  if (!m) return;
  return onMessage(m, callback);
};
