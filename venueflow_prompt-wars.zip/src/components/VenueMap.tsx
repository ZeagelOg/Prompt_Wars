import { useEffect, useRef, useState } from 'react';
import { initGoogleMaps, initVisualization, initMarker } from '../services/maps';
import { subscribeToCrowdDensity } from '../services/data';
import { VENUE_CENTER, GATES } from '../constants/venue';
import type { CrowdData } from '../types/schemas';

export default function VenueMap() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const crowdCirclesRef = useRef<google.maps.Circle[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const loadMaps = async () => {
      // Load modern libraries
      const mapsLib = await initGoogleMaps() as any;
      const markerLib = await initMarker() as any;
      const { Map } = mapsLib;
      const { AdvancedMarkerElement, PinElement } = markerLib;
      
      if (!mapRef.current) return;

      const map = new Map(mapRef.current, {
        center: VENUE_CENTER,
        zoom: 17,
        mapId: 'DEMO_MAP_ID', // Required for AdvancedMarkerElement
        mapTypeId: 'satellite',
        disableDefaultUI: true,
        tilt: 0, // Prevent automatic 45-degree imagery warnings
      });

      mapInstanceRef.current = map;

      // Add Gates using AdvancedMarkerElement
      GATES.forEach(gate => {
        const pin = new PinElement({
          background: '#2563eb',
          borderColor: 'white',
          glyphColor: 'white',
          scale: 1,
        });

        new AdvancedMarkerElement({
          position: { lat: gate.lat, lng: gate.lng },
          map,
          title: gate.name,
          content: pin,
        });
      });

      setIsLoaded(true);
    };

    loadMaps().catch(console.error);
  }, []);

  useEffect(() => {
    if (!isLoaded || !mapInstanceRef.current) return;

    const unsubscribe = subscribeToCrowdDensity((points) => {
      // Clear old circles
      crowdCirclesRef.current.forEach(c => c.setMap(null));
      crowdCirclesRef.current = [];

      // Draw new density circles (Replaces deprecated HeatmapLayer)
      points.forEach(p => {
        const circle = new google.maps.Circle({
          strokeWeight: 0,
          fillColor: '#FF0000',
          fillOpacity: p.density * 0.4,
          map: mapInstanceRef.current,
          center: { lat: p.latitude, lng: p.longitude },
          radius: 15,
        });
        crowdCirclesRef.current.push(circle);
      });
    });

    return () => unsubscribe();
  }, [isLoaded]);

  return (
    <div className="relative w-full h-[400px] md:h-[600px] rounded-2xl overflow-hidden shadow-2xl border-4 border-white dark:border-slate-800 transition-colors">
      <div ref={mapRef} className="w-full h-full" />
      {!isLoaded && (
        <div className="absolute inset-0 bg-gray-100 dark:bg-slate-900 flex items-center justify-center transition-colors">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand dark:border-white" />
        </div>
      )}
      <div className="absolute bottom-4 left-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur p-2 rounded-lg text-xs font-bold shadow transition-colors dark:text-white">
        LIVE CROWD HEATMAP
      </div>
    </div>
  );
}
