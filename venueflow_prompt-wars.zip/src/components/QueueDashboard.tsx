import { useState, useEffect } from 'react';
import { subscribeToPredictions } from '../services/data';
import { GATES } from '../constants/venue';
import type { QueuePrediction } from '../types/schemas';
import { Clock, TrendingUp, TrendingDown, Minus } from 'lucide-react';

export default function QueueDashboard() {
  const [predictions, setPredictions] = useState<Record<string, QueuePrediction>>({});

  useEffect(() => {
    const unsubscribe = subscribeToPredictions(setPredictions);
    return () => unsubscribe();
  }, []);

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {GATES.map(gate => {
        const pred = predictions[gate.id];
        const waitTime = pred?.waitTimeMinutes ?? 0;
        
        return (
          <div 
            key={gate.id}
            className={`p-4 rounded-2xl transition-all duration-300 border-2 ${
              waitTime > 25 
                ? 'bg-red-50 border-red-100 dark:bg-red-950/20 dark:border-red-900/30' 
                : 'bg-white border-transparent shadow-sm dark:bg-slate-900 dark:border-slate-800 dark:shadow-none'
            }`}
          >
            <div className="flex justify-between items-start mb-2">
              <h4 className="font-black text-lg text-slate-900 dark:text-white uppercase tracking-tight">{gate.name}</h4>
              <div className={`p-1.5 rounded-lg ${
                waitTime > 25 
                  ? 'bg-red-500 text-white shadow-lg shadow-red-500/20' 
                  : 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300'
              }`}>
                <Clock size={18} />
              </div>
            </div>
            
            <div className="flex items-baseline gap-2 mt-2">
              <h2 className="text-6xl font-black leading-none m-0 border-none shadow-none bg-transparent">
                {waitTime}
              </h2>
              <div className="text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.2em] self-end mb-1">
                MIN WAIT
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between text-[10px] font-black uppercase tracking-[0.2em]">
              <div className="flex items-center gap-1 text-slate-500 dark:text-slate-500">
                {pred?.trend === 'rising' && <TrendingUp size={14} className="text-red-500" />}
                {pred?.trend === 'falling' && <TrendingDown size={14} className="text-emerald-500" />}
                {pred?.trend === 'stable' && <Minus size={14} />}
                <span className={pred?.trend === 'rising' ? 'text-red-600' : pred?.trend === 'falling' ? 'text-emerald-600' : ''}>
                  {pred?.trend || 'STABLE'}
                </span>
              </div>
              <div className={`h-1.5 w-16 rounded-full bg-gray-100 dark:bg-slate-800 overflow-hidden`}>
                <div 
                  className={`h-full transition-all duration-1000 ${
                    waitTime > 25 ? 'bg-red-500' : 'bg-blue-500'
                  }`}
                  style={{ width: `${Math.min(100, (waitTime / 40) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
