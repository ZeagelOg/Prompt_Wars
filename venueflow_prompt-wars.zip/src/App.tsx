/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { subscribeToAuthChanges, signInWithGoogle, logout, fetchUserProfile } from './services/auth';
import { simulation } from './services/simulation';
import { requestNotificationPermission, onMessageReceived } from './services/notifications';
import VenueMap from './components/VenueMap';
import QueueDashboard from './components/QueueDashboard';
import AIRerouting from './components/AIRerouting';
import StaffDashboard from './components/StaffDashboard';
import { LogOut, User as UserIcon, Shield, LayoutDashboard, Ticket, Moon, Sun, ArrowRight, Home } from 'lucide-react';
import type { UserProfile } from './types/schemas';
import { db } from './services/firebase';
import { doc, updateDoc, setDoc } from 'firebase/firestore';

export default function App() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'attendee' | 'staff' | 'portal'>('portal');
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToAuthChanges(async (user) => {
      if (user) {
        let userProfile = await fetchUserProfile(user.uid);
        
        // FORCE ADMIN UPGRADE FOR THIS EMAIL
        if (user.email === 'bhowmiklisha7@gmail.com' && (!userProfile || userProfile.role !== 'admin')) {
          userProfile = userProfile ? { ...userProfile, role: 'admin' } : {
            uid: user.uid,
            displayName: user.displayName || 'Anonymous',
            email: user.email!,
            photoURL: user.photoURL || null,
            role: 'admin',
            highContrast: false,
            darkMode: false
          };
          try {
            await setDoc(doc(db, 'users', user.uid), userProfile, { merge: true });
          } catch(e) { console.error("Admin upgrade failed:", e); }
        }

        if (userProfile) {
          setProfile(userProfile);
          const themeMode = userProfile.darkMode || false;
          setIsDarkMode(themeMode);
          if (themeMode) {
              document.documentElement.classList.add('dark');
          } else {
              document.documentElement.classList.remove('dark');
          }

          // Personnel can use either view, we start them at the Portal for choice
          if (userProfile.role === 'staff' || userProfile.role === 'admin') {
            simulation.start();
            setView('portal');
          } else {
            simulation.stop();
            setView('attendee');
          }
        } else {
          const fallback: UserProfile = {
            uid: user.uid,
            displayName: user.displayName || 'Anonymous',
            email: user.email || '',
            photoURL: user.photoURL || null,
            role: 'attendee',
            highContrast: false,
            darkMode: false
          };
          setProfile(fallback);
          setIsDarkMode(false);
          document.documentElement.classList.remove('dark');
          simulation.stop();
          setView('attendee');
        }
      } else {
        setProfile(null);
        setIsDarkMode(false);
        document.documentElement.classList.remove('dark');
        simulation.stop();
        setView('attendee');
      }
      setLoading(false);
    });

    return () => {
      unsubscribe();
      simulation.stop();
    };
  }, []);

  const toggleDarkMode = async () => {
    const next = !isDarkMode;
    setIsDarkMode(next);
    if (next) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    if (profile) {
      try {
        await updateDoc(doc(db, 'users', profile.uid), { darkMode: next });
      } catch (e) {
        console.error("Failed to save theme preference:", e);
      }
    }
  };

  const handleLogin = async () => {
    try {
      const userProfile = await signInWithGoogle();
      if (userProfile) {
        setProfile(userProfile);
        // Direct jump to portal for management personnel
        if (userProfile.role === 'staff' || userProfile.role === 'admin') {
          setView('portal');
        }
      }
    } catch (error) {
      console.error("Unexpected login failure:", error);
    }
  };

  if (loading) {
    return (
      <div className="h-screen w-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center gap-4 transition-colors">
        <div className="w-12 h-12 border-4 border-brand border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-black uppercase tracking-[0.3em] animate-pulse text-slate-400">VenueFlow Initializing</p>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-[#f2ede4] text-slate-900'}`}>
      <header className={`fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-50 shadow-lg transition-all duration-500 ${
        view === 'staff' ? 'bg-[#020617] border-b border-slate-800' : 'bg-brand dark:bg-slate-900'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
            <div className="w-4 h-4 bg-brand rounded-sm rotate-45" />
          </div>
          <h1 className="text-xl font-black tracking-tighter uppercase italic !text-white">VenueFlow</h1>
          {profile && (profile.role === 'staff' || profile.role === 'admin') && (
            <div className="ml-4 flex gap-1 bg-black/20 p-1 rounded-xl border border-white/10 overflow-x-auto">
              <button 
                onClick={() => setView('portal')}
                className={`p-2 rounded-lg transition-all ${
                  view === 'portal' 
                    ? 'bg-white text-brand shadow-lg' 
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
                title="Return to Portal"
              >
                <Home size={20} />
              </button>
              <div className="w-px h-6 bg-white/10 my-auto mx-2" />
              <button 
                onClick={() => setView('attendee')}
                className={`flex items-center gap-2 px-5 py-2 rounded-lg font-black text-[11px] tracking-widest uppercase transition-all ${
                  view === 'attendee' 
                    ? 'bg-white text-brand shadow-lg' 
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <Ticket size={16} />
                <span>Attendee</span>
              </button>
              <button 
                onClick={() => setView('staff')}
                className={`flex items-center gap-2 px-5 py-2 rounded-lg font-black text-[11px] tracking-widest uppercase transition-all ${
                  view === 'staff' 
                    ? 'bg-white text-brand shadow-lg' 
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <LayoutDashboard size={16} />
                <span>Staff Control</span>
              </button>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleDarkMode}
            className={`p-2 rounded-full transition-all ${isDarkMode ? 'bg-white/10 text-yellow-400 hover:bg-white/20' : 'bg-black/10 text-white hover:bg-black/20'}`}
            title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          {profile ? (
            <div className="flex items-center gap-3 bg-white/10 pl-3 pr-1 py-1 rounded-full border border-white/20">
              <span className="text-xs font-bold uppercase tracking-widest hidden sm:inline text-white">{profile.displayName}</span>
              <button 
                onClick={() => logout()}
                className="w-8 h-8 rounded-full border-2 border-white/50 overflow-hidden hover:opacity-80 transition-opacity"
                title="Logout"
              >
                {profile.photoURL ? (
                  <img src={profile.photoURL} alt="" referrerPolicy="no-referrer" />
                ) : (
                  <UserIcon size={16} className="text-white mx-auto" />
                )}
              </button>
            </div>
          ) : (
            <button 
              onClick={handleLogin}
              className="bg-white text-brand px-5 py-2 rounded-full font-bold text-sm shadow-lg hover:bg-blue-50 transition-colors"
            >
              Sign In
            </button>
          )}
        </div>
      </header>

      <main className="pt-24 pb-12 max-w-6xl mx-auto px-4 sm:px-6">
        {!profile ? (
          <div className="max-w-2xl mx-auto text-center py-20">
            <h2 className="text-5xl font-black mb-6 tracking-tight leading-tight">
              Predict the crowd.<br/>Pace your experience.
            </h2>
            <p className="text-xl text-slate-500 mb-10 max-w-lg mx-auto">
              Real-time heatmaps and AI routing for the world's premier stadiums. Built for the modern attendee.
            </p>
            <button 
              onClick={handleLogin}
              className="px-10 py-5 bg-brand text-white rounded-2xl font-black text-xl shadow-2xl hover:-translate-y-1 transition-all active:scale-95"
            >
              Enter VenueFlow
            </button>
          </div>
        ) : (
          <div className="space-y-8">
            {view === 'portal' && (profile.role === 'staff' || profile.role === 'admin') ? (
              <div className="max-w-4xl mx-auto py-12">
                <div className="mb-12 text-center">
                  <h2 className="text-4xl font-black uppercase tracking-tighter italic mb-2">Welcome, {profile.displayName}</h2>
                  <p className="text-slate-500 dark:text-slate-400 font-bold tracking-widest uppercase text-xs">Select your destination terminal</p>
                </div>
                
                <div className="grid md:grid-cols-2 gap-8 px-4">
                  <button 
                    onClick={() => setView('attendee')}
                    className="group relative h-80 bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-3xl p-8 text-left transition-all hover:border-brand hover:shadow-2xl overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 p-8 text-slate-100 group-hover:text-brand transition-colors">
                      <Ticket size={64} className="opacity-10 group-hover:opacity-20" />
                    </div>
                    <div className="relative z-10 flex flex-col h-full justify-between">
                      <div>
                        <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 text-brand rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                          <Ticket size={24} />
                        </div>
                        <h3 className="text-3xl font-black uppercase italic tracking-tighter mb-2">Attendee Navigation</h3>
                        <p className="text-slate-500 dark:text-slate-400 font-medium leading-tight">Access the live stadium map, heatmaps, and routing instructions.</p>
                      </div>
                      <div className="flex items-center gap-2 text-brand font-black text-xs uppercase tracking-widest">
                        Initialize Terminal <ArrowRight size={14} />
                      </div>
                    </div>
                  </button>

                  <button 
                    onClick={() => setView('staff')}
                    className="group relative h-80 bg-slate-950 dark:bg-black border-2 border-slate-800 rounded-3xl p-8 text-left transition-all hover:border-brand hover:shadow-2xl overflow-hidden text-white"
                  >
                    <div className="absolute top-0 right-0 p-8 text-slate-800 group-hover:text-brand transition-colors">
                      <LayoutDashboard size={64} className="opacity-20 group-hover:opacity-40" />
                    </div>
                    <div className="relative z-10 flex flex-col h-full justify-between">
                      <div>
                        <div className="w-12 h-12 bg-white/10 text-white rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                          <LayoutDashboard size={24} />
                        </div>
                        <h3 className="text-3xl font-black uppercase italic tracking-tighter mb-2 !text-white">Staff Control</h3>
                        <p className="text-slate-400 font-medium leading-tight">Monitor stadium capacity, gate wait-times, and trigger surge protocols.</p>
                      </div>
                      <div className="flex items-center gap-2 text-white font-black text-xs uppercase tracking-widest opacity-60 group-hover:opacity-100 transition-opacity">
                        Initialize Terminal <ArrowRight size={14} />
                      </div>
                    </div>
                  </button>
                </div>
              </div>
            ) : view === 'staff' && (profile.role === 'staff' || profile.role === 'admin') ? (
              <section className="animate-in fade-in slide-in-from-bottom-4 duration-500 bg-[#020617] -mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8 py-12 min-h-screen">
                <div className="max-w-6xl mx-auto">
                  <div className="flex items-center justify-between mb-8 border-b border-slate-800 pb-8">
                    <div>
                      <h2 className="text-3xl font-black italic !text-white italic tracking-tighter uppercase">Staff Control Center</h2>
                      <p className="text-[10px] text-slate-500 font-mono tracking-[0.3em] mt-2 uppercase font-black">OPERATIONAL DATA | LIVE TELEMETRY</p>
                    </div>
                    <div className="hidden sm:flex items-center gap-4 text-[10px] font-mono">
                      <div className="flex items-center gap-1.5 font-bold text-slate-300"><div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" /> ONLINE</div>
                      <div className="flex items-center gap-1.5 font-bold text-slate-300"><div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.5)]" /> SYNCED</div>
                    </div>
                  </div>
                  <StaffDashboard userProfile={profile} />
                  
                  <div className="mt-12 bg-slate-900/30 p-8 border border-slate-800 rounded-sm">
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-6">Tactical Overlay</h3>
                    <VenueMap />
                  </div>
                </div>
              </section>
            ) : (
              <div className="flex flex-col md:flex-row gap-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex-1 space-y-8">
                  <section>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-600 dark:text-slate-400">Live Navigation</h3>
                      <div className="flex items-center gap-3">
                        {(profile?.role === 'staff' || profile?.role === 'admin') && (
                          <button 
                            onClick={() => setView('staff')}
                            className="flex items-center gap-2 text-[10px] font-black uppercase text-brand bg-brand/10 border border-brand/20 px-3 py-1.5 rounded-lg hover:bg-brand hover:text-white transition-all shadow-sm"
                          >
                            <LayoutDashboard size={12} />
                            Staff Control
                          </button>
                        )}
                        <div className="flex items-center gap-2 text-[10px] font-bold uppercase text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded">
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                          Live Feed
                        </div>
                      </div>
                    </div>
                    <VenueMap />
                  </section>

                  <AIRerouting />
                </div>

                <div className="w-full md:w-80 space-y-8">
                  <section>
                    <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-600 dark:text-slate-400 mb-4">Entry Points</h3>
                    <QueueDashboard />
                  </section>
                </div>
              </div>
            )}
          </div>
        )}
      </main>
      
      <div id="sc-announcements" className="sr-only" aria-live="polite"></div>
    </div>
  );
}
