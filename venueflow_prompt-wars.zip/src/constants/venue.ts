/**
 * Venue Constants for Simulation
 * Defining boundaries for a mock stadium (e.g., centered in a sports complex area)
 */

export const VENUE_CENTER = { lat: 34.0125, lng: -118.2878 }; // Example: Near Exposition Park, LA

export const GATES = [
  { id: 'gate-a', name: 'Gate A (North)', lat: 34.0135, lng: -118.2878 },
  { id: 'gate-b', name: 'Gate B (East)', lat: 34.0125, lng: -118.2868 },
  { id: 'gate-c', name: 'Gate C (South)', lat: 34.0115, lng: -118.2878 },
  { id: 'gate-d', name: 'Gate D (West)', lat: 34.0125, lng: -118.2888 },
];

export const VENUE_BOUNDS = {
  north: 34.0140,
  south: 34.0110,
  east: -118.2858,
  west: -118.2898,
};

export const SIMULATION_INTERVAL_MS = 3000;
