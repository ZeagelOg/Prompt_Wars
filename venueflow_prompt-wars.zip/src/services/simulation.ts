import { db } from './firebase';
import { collection, addDoc, doc, setDoc, serverTimestamp, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { VENUE_BOUNDS, GATES, SIMULATION_INTERVAL_MS } from '../constants/venue';
import { CrowdDataSchema, type CrowdData, type QueuePrediction } from '../types/schemas';

class SimulationEngine {
  private intervalId: NodeJS.Timeout | null = null;
  private isSurgeActive = false;

  start() {
    if (this.intervalId) return;
    
    this.intervalId = setInterval(() => {
      this.generateCrowdUpdate();
    }, SIMULATION_INTERVAL_MS);
    
    console.log('Simulation Engine Started');
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  setSurge(active: boolean) {
    this.isSurgeActive = active;
    console.log(`Gate B Surge: ${active ? 'ACTIVE' : 'INACTIVE'}`);
  }

  getSurge() {
    return this.isSurgeActive;
  }

  private async generateCrowdUpdate() {
    const crowdData: CrowdData[] = [];
    
    // Generate random clusters
    for (let i = 0; i < 20; i++) {
      const isSurgeSample = this.isSurgeActive && Math.random() > 0.3;
      const targetGate = isSurgeSample ? GATES.find(g => g.id === 'gate-b') : GATES[Math.floor(Math.random() * GATES.length)];
      
      const latOffset = (Math.random() - 0.5) * 0.001;
      const lngOffset = (Math.random() - 0.5) * 0.001;
      
      const point = {
        latitude: (targetGate?.lat || VENUE_BOUNDS.north) + latOffset,
        longitude: (targetGate?.lng || VENUE_BOUNDS.west) + lngOffset,
        density: Math.random() * (isSurgeSample ? 1.0 : 0.6),
        timestamp: Date.now(),
        gateId: targetGate?.id,
      };

      try {
        const validated = CrowdDataSchema.parse(point);
        crowdData.push(validated);
      } catch (e) {
        console.error("Validation error in simulation:", e);
      }
    }

    // Batch upload (simplified for demo)
    try {
      const crowdCol = collection(db, 'crowd_snapshots');
      await addDoc(crowdCol, {
        points: crowdData,
        timestamp: serverTimestamp(),
        isSurge: this.isSurgeActive
      });
      
      // Update queue predictions based on density
      await this.updateQueuePredictions(crowdData);
    } catch (error: any) {
      if (error.code === 'permission-denied') {
        console.warn("Simulation write suppressed: Insufficient permissions (Attendee role?)");
        this.stop(); // Stop simulation if we can't write
      } else {
        console.error('Simulation upload failed:', error);
      }
    }
  }

  private async updateQueuePredictions(data: CrowdData[]) {
    try {
      for (const gate of GATES) {
        const gatePoints = data.filter(p => p.gateId === gate.id);
        const avgDensity = gatePoints.length > 0 
          ? gatePoints.reduce((acc, p) => acc + p.density, 0) / gatePoints.length 
          : Math.random() * 0.2;
          
        const waitTime = Math.round(avgDensity * 40); // Simple linear prediction, max 40 mins
        
        const prediction: QueuePrediction = {
          gateId: gate.id,
          waitTimeMinutes: waitTime,
          trend: waitTime > 20 ? 'rising' : (waitTime < 5 ? 'falling' : 'stable'),
          lastUpdated: Date.now(),
        };

        await setDoc(doc(db, 'predictions', gate.id), prediction);
      }
    } catch (error) {
      console.warn("Prediction update suppressed: Insufficient permissions");
    }
  }
}

export const simulation = new SimulationEngine();
