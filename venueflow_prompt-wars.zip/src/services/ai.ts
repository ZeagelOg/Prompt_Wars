import { GoogleGenAI } from "@google/genai";
import { type QueuePrediction } from "../types/schemas";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const getSmartReroutingSuggestion = async (
  currentGate: string,
  allPredictions: QueuePrediction[]
) => {
  const prompt = `
    You are VenueFlow AI, an expert crowd management assistant.
    Current Venue State:
    ${allPredictions.map(p => `- ${p.gateId}: ${p.waitTimeMinutes} min wait (${p.trend})`).join('\n')}
    
    User is currently at ${currentGate}. 
    Provide a concise, helpful suggestion for rerouting if the current gate is overcrowded.
    Include the estimated time saving.
    Response should be professional and encouraging.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("AI Rerouting Error:", error);
    return "Please consider checking Gate D for shorter wait times.";
  }
};
