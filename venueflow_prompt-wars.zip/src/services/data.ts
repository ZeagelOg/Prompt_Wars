import { db, handleFirestoreError } from './firebase';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { type CrowdData, type QueuePrediction } from '../types/schemas';

export const subscribeToCrowdDensity = (callback: (data: CrowdData[]) => void) => {
  const q = query(
    collection(db, 'crowd_snapshots'),
    orderBy('timestamp', 'desc'),
    limit(1)
  );

  return onSnapshot(q, (snapshot) => {
    if (snapshot.empty) return;
    const latest = snapshot.docs[0].data();
    callback(latest.points as CrowdData[]);
  }, (error) => {
    handleFirestoreError(error, 'list', 'crowd_snapshots');
  });
};

export const subscribeToPredictions = (callback: (predictions: Record<string, QueuePrediction>) => void) => {
  return onSnapshot(collection(db, 'predictions'), (snapshot) => {
    const predictions: Record<string, QueuePrediction> = {};
    snapshot.forEach(doc => {
      predictions[doc.id] = doc.data() as QueuePrediction;
    });
    callback(predictions);
  }, (error) => {
    handleFirestoreError(error, 'list', 'predictions');
  });
};
