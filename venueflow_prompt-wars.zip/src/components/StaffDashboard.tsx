import { useEffect, useState } from 'react';
import { subscribeToPredictions, subscribeToCrowdDensity } from '../services/data';
import { simulation } from '../services/simulation';
import { GATES } from '../constants/venue';
import type { QueuePrediction, CrowdData, UserProfile } from '../types/schemas';
import { Users, Timer, AlertTriangle, ShieldCheck, Activity } from 'lucide-react';
import { motion } from 'motion/react';

interface StaffDashboardProps {
  userProfile: UserProfile;
}

export default function StaffDashboard({ userProfile }: StaffDashboardProps) {
  const [predictions, setPredictions] = useState<Record<string, QueuePrediction>>({});
  const [crowdPoints, setCrowdPoints] = useState<CrowdData[]>([]);
  const [isSurgeActive, setIsSurgeActive] = useState(simulation.getSurge());

  useEffect(() => {
    const unsubPredictions = subscribeToPredictions(setPredictions);
    const unsubCrowd = subscribeToCrowdDensity(setCrowdPoints);
    return () => {
      unsubPredictions();
      unsubCrowd();
    };
  }, []);

  const totalAttendees = crowdPoints.length * 100; // Mock scaling
  const predictionValues = Object.values(predictions) as QueuePrediction[];
  const avgWaitTime = predictionValues.length > 0 
    ? predictionValues.reduce((acc, p) => acc + (p.waitTimeMinutes || 0), 0) / predictionValues.length
    : 0;

  const broadcastAlert = () => {
    alert("BROADCAST: 'Gate B is currently at capacity. Please use Gate A or C for faster entry.' sent to all active PWA instances.");
  };

  return (
    <div className="space-y-6 font-mono text-xs uppercase tracking-wider">
      {/* KPI Ribbons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Estimated Load', value: totalAttendees.toLocaleString(), icon: Users, color: 'text-blue-500' },
          { label: 'Avg System Wait', value: `${avgWaitTime.toFixed(1)}m`, icon: Timer, color: 'text-emerald-500' },
          { label: 'Active Gates', value: GATES.length, icon: ShieldCheck, color: 'text-purple-500' },
          { label: 'System Health', value: 'Nominal', icon: Activity, color: 'text-slate-500' },
        ].map((kpi, i) => (
          <div key={i} className="bg-slate-900/50 dark:bg-slate-900/80 p-6 border border-slate-800 rounded-sm shadow-xl flex flex-col justify-between h-32 transition-all hover:border-slate-700">
            <div className="flex justify-between items-start">
              <span className="font-bold text-slate-500 tracking-[0.2em]">{kpi.label}</span>
              <kpi.icon size={16} className={kpi.color} />
            </div>
            <h3 className="text-3xl font-black mt-2 leading-none m-0 border-none shadow-none bg-transparent">
              {kpi.value}
            </h3>
          </div>
        ))}
      </div>

      {/* Main Grid View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Gate Control Table */}
        <div className="lg:col-span-2 bg-[#020617] border border-slate-800 rounded-sm overflow-hidden shadow-2xl">
          <div className="p-6 border-b border-slate-800 bg-slate-900/30 flex flex-wrap gap-4 justify-between items-center">
            <h4 className="font-black italic text-slate-400 dark:text-slate-300 uppercase tracking-widest text-[10px]">Venue Entry Operations</h4>
            <div className="flex items-center gap-6">
               <button 
                onClick={broadcastAlert}
                className="text-[9px] bg-slate-800/50 border border-slate-700 text-slate-300 px-4 py-2 font-black rounded hover:bg-slate-700 active:scale-95 transition-all"
              >
                BROADCAST GLOBAL ALERT
              </button>
               <span className="text-[9px] text-slate-500 font-bold hidden sm:block">REFRESHES EVERY 3S</span>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <tbody className="divide-y divide-slate-800/50">
                {GATES.map((gate) => {
                  const pred = predictions[gate.id];
                  const wait = pred?.waitTimeMinutes || 0;
                  return (
                    <tr key={gate.id} className="hover:bg-slate-800/20 transition-colors group">
                      <td className="p-6 font-bold text-slate-400 group-hover:text-slate-200 transition-colors">{gate.name}</td>
                      <td className="p-6 text-right">
                        <span className="text-slate-600 dark:text-slate-500 font-bold mr-8 tracking-[0.1em]">{pred?.trend || 'Stable'}</span>
                        <div className={`px-4 py-1.5 rounded-sm inline-block text-[10px] font-black text-white ${
                          wait > 20 ? 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]' : 
                          wait > 10 ? 'bg-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.3)]' : 
                          'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                        }`}>
                          {wait > 20 ? 'CRITICAL' : wait > 10 ? 'CONGESTED' : 'OPTIMAL'}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Coordination Log */}
        <div className="bg-slate-900/40 border border-slate-800 p-6 rounded-sm shadow-xl transition-all hover:bg-slate-900/60 h-full">
          <h4 className="font-black italic text-slate-400 mb-6 uppercase tracking-widest text-[10px]">Coordination Log</h4>
          <div className="space-y-6 text-[10px]">
            <div className="border-l-2 border-emerald-500/30 pl-4 py-1">
              <span className="font-bold text-slate-600 block mb-1">[09:42:01]</span> 
              <span className="text-slate-500 italic block">System: All biometric scanners nominal at North Plaza.</span>
            </div>
            <div className="border-l-2 border-blue-500/30 pl-4 py-1">
              <span className="font-bold text-slate-600 block mb-1">[09:41:15]</span> 
              <span className="text-slate-500 italic block">Staff: Roving unit 04 deployed to Gate D.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
