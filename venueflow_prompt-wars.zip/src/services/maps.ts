import { setOptions, importLibrary } from '@googlemaps/js-api-loader';

setOptions({
  key: (process.env as any).VITE_GOOGLE_MAPS_API_KEY,
  version: 'beta', // Using beta to ensure access to newest features like AdvancedMarkerElement
} as any);

export const initGoogleMaps = () => importLibrary('maps');
export const initMarker = () => importLibrary('marker');
export const initVisualization = () => importLibrary('visualization');
