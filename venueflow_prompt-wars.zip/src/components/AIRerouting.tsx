import { useState, useEffect } from 'react';
import { getSmartReroutingSuggestion } from '../services/ai';
import { subscribeToPredictions } from '../services/data';
import { Bot, Sparkles, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { QueuePrediction } from '../types/schemas';

export default function AIRerouting() {
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [predictions, setPredictions] = useState<Record<string, QueuePrediction>>({});

  useEffect(() => {
    return subscribeToPredictions(setPredictions);
  }, []);

  const getSuggestion = async () => {
    setLoading(true);
    
    const gateData = (Object.entries(predictions) as [string, QueuePrediction][]).map(([id, p]) => ({
        gateId: id,
        waitTimeMinutes: p.waitTimeMinutes,
        trend: p.trend,
        lastUpdated: p.lastUpdated
    }));

    const busiestGate = (Object.values(predictions) as QueuePrediction[]).sort((a, b) => b.waitTimeMinutes - a.waitTimeMinutes)[0];
    const startingGate = busiestGate?.gateId || 'Main Entry';

    const result = await getSmartReroutingSuggestion(startingGate, gateData);
    setSuggestion(result);
    setLoading(false);
    
    // Announce to screen reader
    const announcer = document.getElementById('sc-announcements');
    if (announcer) announcer.textContent = `New AI Rerouting Suggestion: ${result}`;
  };

  return (
    <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-4">
          <div className="p-2 bg-white/20 rounded-lg">
            <Bot size={20} />
          </div>
          <span className="font-bold tracking-tight uppercase text-sm">VenueFlow Intelligence</span>
        </div>

        <h3 className="text-xl font-bold mb-4 leading-tight">
          Navigate the crowd with AI-powered routing
        </h3>

        <AnimatePresence mode="wait">
          {suggestion ? (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20 mb-6"
            >
              <p className="text-sm leading-relaxed italic">
                "{suggestion}"
              </p>
            </motion.div>
          ) : (
            <p className="text-sm text-white/70 mb-6">
              Our AI analyzes real-time density patterns to find your fastest path to the seat.
            </p>
          )}
        </AnimatePresence>

        <button 
          onClick={getSuggestion}
          disabled={loading}
          className="group flex items-center gap-2 bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-blue-50 dark:hover:bg-slate-800 transition-all disabled:opacity-50"
        >
          {loading ? 'Analyzing...' : 'Get Best Route'}
          {!loading && <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />}
        </button>
      </div>

      <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
        <Sparkles size={120} />
      </div>
    </div>
  );
}
